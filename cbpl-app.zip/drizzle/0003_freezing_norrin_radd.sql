ALTER TABLE "products" ADD COLUMN "bedrooms" integer;--> statement-breakpoint
ALTER TABLE "products" ADD COLUMN "bathrooms" integer;