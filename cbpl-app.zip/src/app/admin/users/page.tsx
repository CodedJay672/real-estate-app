import React from "react";

const Users = () => {
  return <div>Users Page</div>;
};

export default Users;
