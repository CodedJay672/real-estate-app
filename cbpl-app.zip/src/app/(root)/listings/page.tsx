import React from "react";

const ProductListings = () => {
  return <div>Product Listings</div>;
};

export default ProductListings;
